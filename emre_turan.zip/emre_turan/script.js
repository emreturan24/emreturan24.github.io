function hesaplaNot() {
    let adsoyad = document.getElementById("adsoyad").value;
    let vize = parseFloat(document.getElementById("vize").value);
    let final = parseFloat(document.getElementById("final").value);

    let ortalama = vize * 0.4 + final * 0.6;
    let harfNotu = "";
    let durum = "";

    if (ortalama >= 90) harfNotu = "AA";
    else if (ortalama >= 80) harfNotu = "BA";
    else if (ortalama >= 70) harfNotu = "BB";
    else if (ortalama >= 60) harfNotu = "CB";
    else if (ortalama >= 50) harfNotu = "CC";
    else harfNotu = "FF";

    if (ortalama >= 50) durum = "Geçti";
    else durum = "Kaldı";

    document.getElementById("sonuc1").innerHTML =
        "Öğrenci: " + adsoyad +
        "<br>Ortalama: " + ortalama.toFixed(2) +
        "<br>Harf Notu: " + harfNotu +
        "<br>Durum: " + durum;
}

function donustur() {
    let deger = parseFloat(document.getElementById("deger").value);
    let secim = document.getElementById("secim").value;
    let sonuc;

    if (secim == "cf") {
        sonuc = (deger * 9/5) + 32;
        document.getElementById("sonuc2").innerHTML = deger + " °C = " + sonuc.toFixed(2) + " °F";
    }
    else if (secim == "fc") {
        sonuc = (deger - 32) * 5/9;
        document.getElementById("sonuc2").innerHTML = deger + " °F = " + sonuc.toFixed(2) + " °C";
    }
    else if (secim == "mk") {
        sonuc = deger / 1000;
        document.getElementById("sonuc2").innerHTML = deger + " m = " + sonuc.toFixed(2) + " km";
    }
    else if (secim == "km") {
        sonuc = deger * 1000;
        document.getElementById("sonuc2").innerHTML = deger + " km = " + sonuc.toFixed(2) + " m";
    }
}